This is the README file for:

  Verilog Language and Application- version 28.0

The software products and versions required for this course are:

->  XCELIUM23.09
->  GENUS211

Although you can expect the Cadence software to run on any platform
Cadence supports, the database is tested only with version XCELIUM23.09 and GENUS211 on:
        LINUX RHEL 7
        LINUX CentOS 7.4
        LINUX RHEL 8
        LINUX SLES 15   

The lab database is not tested on any other platform or tool version.
The lab database is not tested on AIX because we do not support gcc on AIX.

Make sure that you have the Xcleium 23.09 version somewhere in your cshrc or
the environemnt setup script.

To cofirm this execute the following command:

which xrun

This should show the entire path pointing to the 23.09 Xcelium tool installation path.


